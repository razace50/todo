import { Button } from "../ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "../ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "../ui/table";
import AddTaskDialog from "./components/AddTaskDialog";
import DeleteTask from "./components/DeleteTask";
import EditTask from "./components/EditTask";
import ViewTask from "./components/ViewTask";

const Dashboard = () => {
  const tasks = [
    {
      title: "Task 1",
      description: "Task 1 description",
      dueDate: "2021-09-30",
      status: "pending",
      priority: "high",
      createdAt: "2021-09-30",
      updatedAt: "2021-09-30",
    },
    {
      title: "Task 2",
      description: "Task 2 description",
      dueDate: "2021-09-30",
      status: "pending",
      priority: "high",
      createdAt: "2021-09-30",
      updatedAt: "2021-09-30",
    },
    {
      title: "Task 3",
      description: "Task 3 description",
      dueDate: "2021-09-30",
      status: "pending",
      priority: "high",
      createdAt: "2021-09-30",
      updatedAt: "2021-09-30",
    },
    {
      title: "Task 4",
      description: "Task 4 description",
      dueDate: "2021-09-30",
      status: "pending",
      priority: "high",
      createdAt: "2021-09-30",
      updatedAt: "2021-09-30",
    },
  ];
  return (
    <div className="container mx-auto">
      <Card className="my-20">
        <CardHeader>
          <div className="flex justify-between items-center">
            <div>
              <CardTitle>List of Available tasks</CardTitle>
            </div>
            <div className="flex pr-6">
              <AddTaskDialog />
            </div>
          </div>
          <CardDescription>
            You can see the list of Available tasks here.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow className="capitalize">
                <TableHead>Title</TableHead>
                <TableHead>Description</TableHead>
                <TableHead>Due Date</TableHead>
                <TableHead>status</TableHead>
                <TableHead>Priority</TableHead>
                <TableHead>Created At</TableHead>
                <TableHead>Updated At</TableHead>
                <TableHead></TableHead>
              </TableRow>
            </TableHeader>
            {/* Table Body */}
            <TableBody>
              {tasks.map((task, index) => (
                <TableRow key={index} className="py-2">
                  <TableCell>{task.title}</TableCell>
                  <TableCell>{task.description}</TableCell>
                  <TableCell>{task.dueDate}</TableCell>
                  <TableCell>{task.status}</TableCell>
                  <TableCell>{task.priority}</TableCell>
                  <TableCell>{task.createdAt}</TableCell>
                  <TableCell>{task.updatedAt}</TableCell>
                  <TableHead>
                    <Button variant={"ghost"} size={"icon"}>
                      <ViewTask
                        task={{
                          title: "",
                          dueDate: "",
                          status: "",
                          priority: "",
                          description: "",
                        }}
                      />
                    </Button>

                    <Button variant={"ghost"} size={"icon"}>
                      <EditTask />
                    </Button>
                    <Button variant={"ghost"} size={"icon"}>
                      <DeleteTask />
                    </Button>
                  </TableHead>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
};

export default Dashboard;
